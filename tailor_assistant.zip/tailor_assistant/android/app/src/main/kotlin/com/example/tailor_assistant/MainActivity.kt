package com.example.tailor_assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
